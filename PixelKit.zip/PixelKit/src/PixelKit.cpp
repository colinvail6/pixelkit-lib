#include "PixelKit.h"

PixelKit::PixelKit(uint8_t pin, uint8_t width, uint8_t height)
    : _pin(pin), _width(width), _height(height),
      _buttonAPin(23), _buttonBPin(18), _buttonResetPin(5),
      _joystickUpPin(35), _joystickDownPin(34),
      _joystickLeftPin(26), _joystickRightPin(25),
      _joystickClickPin(27),
      _dialPin(36), _micPin(39),
      _serpentine(false), _pixels(nullptr) {}

void PixelKit::begin() {
    if (!_pixels) {
        _pixels = new Adafruit_NeoPixel(_width * _height, _pin, NEO_GRB + NEO_KHZ800);
        _pixels->begin();
        _pixels->show();
    }
    pinMode(_buttonAPin, INPUT_PULLUP);
    pinMode(_buttonBPin, INPUT_PULLUP);
    pinMode(_buttonResetPin, INPUT_PULLUP);
    pinMode(_joystickUpPin, INPUT_PULLUP);
    pinMode(_joystickDownPin, INPUT_PULLUP);
    pinMode(_joystickLeftPin, INPUT_PULLUP);
    pinMode(_joystickRightPin, INPUT_PULLUP);
    pinMode(_joystickClickPin, INPUT_PULLUP);
    pinMode(_dialPin, INPUT);
    pinMode(_micPin, INPUT);
}

uint32_t PixelKit::Color(uint8_t r, uint8_t g, uint8_t b) { return Adafruit_NeoPixel::Color(r,g,b); }
void PixelKit::setBrightness(uint8_t brightness) { if(_pixels) _pixels->setBrightness(brightness); }
void PixelKit::setSerpentine(bool enabled) { _serpentine = enabled; }
int PixelKit::_mapXYtoIndex(uint8_t x, uint8_t y) { return (!_serpentine) ? y*_width+x : (y%2==0 ? y*_width+x : y*_width+(_width-1-x)); }
void PixelKit::setPixel(uint8_t x, uint8_t y, uint32_t color){ if(_pixels) _pixels->setPixelColor(_mapXYtoIndex(x,y), color); }
void PixelKit::setPixelColor(uint8_t x, uint8_t y, uint8_t r, uint8_t g, uint8_t b){ setPixel(x,y,Color(r,g,b)); }
void PixelKit::fill(uint32_t color){ if(_pixels) for(int i=0;i<_width*_height;i++) _pixels->setPixelColor(i,color); }
void PixelKit::render(){ if(_pixels) _pixels->show(); }
int PixelKit::readJoystick(){
    if(digitalRead(_joystickUpPin) == LOW) return JOYSTICK_UP;
    if(digitalRead(_joystickDownPin) == LOW) return JOYSTICK_DOWN;
    if(digitalRead(_joystickLeftPin) == LOW) return JOYSTICK_LEFT;
    if(digitalRead(_joystickRightPin) == LOW) return JOYSTICK_RIGHT;
    if(digitalRead(_joystickClickPin) == LOW) return JOYSTICK_CLICK;
    return -1;
}
int PixelKit::readButtonA() { return digitalRead(_buttonAPin); }
int PixelKit::readButtonB() { return digitalRead(_buttonBPin); }
int PixelKit::readButtonReset() { return digitalRead(_buttonResetPin); }
int PixelKit::readDial(){ return analogRead(_dialPin); }
int PixelKit::readMic(){ return analogRead(_micPin); }