#ifndef PIXELKIT_H
#define PIXELKIT_H
#include <Arduino.h>
#include <Adafruit_NeoPixel.h>

// Joystick directions
#define JOYSTICK_UP     0
#define JOYSTICK_DOWN   1
#define JOYSTICK_LEFT   2
#define JOYSTICK_RIGHT  3
#define JOYSTICK_CLICK  4
#define BUTTON_A      5
#define BUTTON_B      6
#define BUTTON_RESET  7

class PixelKit {
public:
    PixelKit(uint8_t pin = 4, uint8_t width = 16, uint8_t height = 8);
    void begin();
    void setPixel(uint8_t x, uint8_t y, uint32_t color);
    void setPixelColor(uint8_t x, uint8_t y, uint8_t r, uint8_t g, uint8_t b);
    void fill(uint32_t color);
    void render();
    int readButtonA();
    int readButtonB();
    int readButtonReset();
    int readJoystick();
    int readDial();
    int readMic();
    void setBrightness(uint8_t brightness);
    void setSerpentine(bool enabled);
    static uint32_t Color(uint8_t r, uint8_t g, uint8_t b);
private:
    uint8_t _pin, _width, _height;
    Adafruit_NeoPixel* _pixels;
    uint8_t _buttonAPin, _buttonBPin,_buttonResetPin, _joystickUpPin, _joystickDownPin, _joystickLeftPin, _joystickRightPin, _joystickClickPin;
    uint8_t _dialPin, _micPin;
    bool _serpentine;
    int _mapXYtoIndex(uint8_t x, uint8_t y);
};
#endif